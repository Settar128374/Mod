package com.modid;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ClickGUI.
 * Modul: sol tik = ac/kapat | sag tik veya sagdaki "+" = ayarlari ac/kapat
 * Baslik: surukle = tasi | sag tik = paneli kapat/ac
 * Ayarlar: Num = kaydirici (basili tutup surukle) | Bool = tikla | Mode = tikla, sonraki secenek
 */
@Environment(EnvType.CLIENT)
public class ModIDScreen extends Screen {

	private static final int PANEL_W = 110;
	private static final int HEADER_H = 18;
	private static final int ROW_H = 15;
	private static final int SET_H = 17;
	private static final int GAP = 8;

	private static final int COL_BG = 0xCC101418;
	private static final int COL_HEADER = 0xF00B0E11;
	private static final int COL_SET_BG = 0x55000000;
	private static final int COL_HOVER = 0x33FFFFFF;
	private static final int COL_ON = 0xFF5CF2E0;
	private static final int COL_OFF = 0xFFB0B7BC;
	private static final int COL_TRACK = 0xFF2A3036;
	private static final int COL_DIM = 0x55000000;

	private static final class Row {
		final int y, h;
		final Module m;
		final Setting s; // null ise modul satiri

		Row(int y, int h, Module m, Setting s) {
			this.y = y;
			this.h = h;
			this.m = m;
			this.s = s;
		}
	}

	private static final class Panel {
		final String name;
		final List<Module> mods;
		int x = -1, y = 10;
		boolean open = true;

		Panel(String name) {
			this.name = name;
			this.mods = Modules.inCategory(name);
		}
	}

	private static final List<Panel> PANELS = new ArrayList<>();
	private static final Set<Module> EXPANDED = new HashSet<>();

	static {
		for (String c : new String[]{"Combat", "Movement", "Render"}) {
			PANELS.add(new Panel(c));
		}
	}

	private Panel dragging;
	private int dragDX, dragDY;
	private Setting.Num sliderSetting;
	private Panel sliderPanel;

	public ModIDScreen() {
		super(Text.literal("ModID Client"));
	}

	public static boolean isEnabled(String module) {
		return Modules.isEnabled(module);
	}

	@Override
	protected void init() {
		int total = PANELS.size() * PANEL_W + (PANELS.size() - 1) * GAP;
		int startX = Math.max(4, (this.width - total) / 2);
		for (int i = 0; i < PANELS.size(); i++) {
			Panel p = PANELS.get(i);
			if (p.x < 0) p.x = startX + i * (PANEL_W + GAP);
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	// ----------------------------------------------------------- yerlesim

	private List<Row> rows(Panel p) {
		List<Row> r = new ArrayList<>();
		if (!p.open) return r;
		int y = p.y + HEADER_H + 1;
		for (Module m : p.mods) {
			r.add(new Row(y, ROW_H, m, null));
			y += ROW_H;
			if (EXPANDED.contains(m)) {
				for (Setting s : m.settings) {
					r.add(new Row(y, SET_H, m, s));
					y += SET_H;
				}
			}
		}
		return r;
	}

	private int height(Panel p) {
		if (!p.open) return HEADER_H;
		int end = p.y + HEADER_H + 1;
		for (Row r : rows(p)) end = Math.max(end, r.y + r.h);
		return end + 2 - p.y;
	}

	// ------------------------------------------------------------- cizim

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		ctx.fill(0, 0, this.width, this.height, COL_DIM);

		for (Panel p : PANELS) {
			ctx.fill(p.x, p.y, p.x + PANEL_W, p.y + height(p), COL_BG);
			ctx.fill(p.x, p.y, p.x + PANEL_W, p.y + HEADER_H, COL_HEADER);
			ctx.fill(p.x, p.y + HEADER_H - 1, p.x + PANEL_W, p.y + HEADER_H, 0x665CF2E0);
			ctx.drawCenteredTextWithShadow(this.textRenderer, p.name,
					p.x + PANEL_W / 2, p.y + (HEADER_H - 8) / 2, 0xFFFFFFFF);

			for (Row r : rows(p)) {
				if (r.s == null) drawModule(ctx, p, r, mouseX, mouseY);
				else drawSetting(ctx, p, r);
			}
		}
	}

	private void drawModule(DrawContext ctx, Panel p, Row r, int mx, int my) {
		if (inRect(mx, my, p.x, r.y, PANEL_W, r.h)) {
			ctx.fill(p.x + 2, r.y, p.x + PANEL_W - 2, r.y + r.h, COL_HOVER);
		}
		boolean on = r.m.isEnabled();
		if (on) ctx.fill(p.x + 2, r.y + 3, p.x + 4, r.y + r.h - 3, COL_ON);
		ctx.drawTextWithShadow(this.textRenderer, r.m.name, p.x + 8, r.y + (r.h - 8) / 2,
				on ? COL_ON : COL_OFF);
		if (!r.m.settings.isEmpty()) {
			ctx.drawTextWithShadow(this.textRenderer, EXPANDED.contains(r.m) ? "-" : "+",
					p.x + PANEL_W - 10, r.y + (r.h - 8) / 2, COL_OFF);
		}
	}

	private void drawSetting(DrawContext ctx, Panel p, Row r) {
		ctx.fill(p.x + 2, r.y, p.x + PANEL_W - 2, r.y + r.h, COL_SET_BG);
		Setting s = r.s;
		if (s instanceof Setting.Num n) {
			ctx.drawTextWithShadow(this.textRenderer, n.name + ": " + n.display(),
					p.x + 8, r.y + 2, COL_OFF);
			int tx = p.x + 6, tw = PANEL_W - 12, ty = r.y + r.h - 5;
			ctx.fill(tx, ty, tx + tw, ty + 2, COL_TRACK);
			double t = (n.get() - n.min) / (n.max - n.min);
			ctx.fill(tx, ty, tx + (int) (tw * t), ty + 2, COL_ON);
		} else if (s instanceof Setting.Bool b) {
			ctx.drawTextWithShadow(this.textRenderer, b.name + ": " + (b.get() ? "ON" : "OFF"),
					p.x + 8, r.y + (r.h - 8) / 2, b.get() ? COL_ON : COL_OFF);
		} else if (s instanceof Setting.Mode md) {
			ctx.drawTextWithShadow(this.textRenderer, md.name + ": " + md.get(),
					p.x + 8, r.y + (r.h - 8) / 2, COL_OFF);
		}
	}

	// --------------------------------------------------------- etkilesim

	private void setSlider(double mx) {
		if (sliderSetting == null || sliderPanel == null) return;
		double t = (mx - (sliderPanel.x + 6)) / (PANEL_W - 12);
		t = Math.max(0, Math.min(1, t));
		sliderSetting.set(sliderSetting.min + t * (sliderSetting.max - sliderSetting.min));
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		for (int i = PANELS.size() - 1; i >= 0; i--) {
			Panel p = PANELS.get(i);
			if (!inRect(mx, my, p.x, p.y, PANEL_W, height(p))) continue;

			PANELS.remove(i);
			PANELS.add(p);

			if (my < p.y + HEADER_H) {
				if (button == 0) {
					dragging = p;
					dragDX = (int) mx - p.x;
					dragDY = (int) my - p.y;
				} else if (button == 1) {
					p.open = !p.open;
				}
				return true;
			}

			for (Row r : rows(p)) {
				if (my < r.y || my >= r.y + r.h) continue;

				if (r.s == null) {
					boolean plus = !r.m.settings.isEmpty() && mx >= p.x + PANEL_W - 16;
					if (button == 1 || (button == 0 && plus)) {
						if (!r.m.settings.isEmpty() && !EXPANDED.remove(r.m)) EXPANDED.add(r.m);
					} else if (button == 0) {
						r.m.toggle();
					}
				} else if (button == 0) {
					if (r.s instanceof Setting.Num n) {
						sliderSetting = n;
						sliderPanel = p;
						setSlider(mx);
					} else if (r.s instanceof Setting.Bool b) {
						b.toggle();
					} else if (r.s instanceof Setting.Mode md) {
						md.next();
					}
				}
				break;
			}
			return true;
		}
		return super.mouseClicked(mx, my, button);
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (sliderSetting != null && button == 0) {
			setSlider(mx);
			return true;
		}
		if (dragging != null && button == 0) {
			dragging.x = clamp((int) mx - dragDX, 0, this.width - PANEL_W);
			dragging.y = clamp((int) my - dragDY, 0, this.height - HEADER_H);
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		dragging = null;
		sliderSetting = null;
		sliderPanel = null;
		return super.mouseReleased(mx, my, button);
	}

	private static boolean inRect(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	private static int clamp(int v, int lo, int hi) {
		return Math.max(lo, Math.min(hi, v));
	}
}
